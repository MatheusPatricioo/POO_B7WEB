<?php
require 'calculadora.php';


$calculadora = new calculadora();
$calculadora->setNumero1(5);
$calculadora->setNumero2(10);

$calculadora->soma();

$calculadora2 = new calculadora();
$calculadora2->setNumero1(30);
$calculadora2->setNumero2(100);

$calculadora2->div();

echo "Implementação do método Somar: " . $calculadora->getResultado() . "<br>";
echo "Implementação do método divisão: " . $calculadora2->getResultado() ."<br>";