<?php
class Calculadora {
    private $numero1;
    private $numero2;
    private $resultado;

    public function __construct() {
        $this->numero1 = 0;
        $this->numero2 = 0;
    }

    public function setNumero1($numero) {
        $this->numero1 = $numero;
    }

    public function getNumero1() {
        return $this->numero1;
    }

    public function setNumero2($numero) {
        $this->numero2 = $numero;
    }

    public function getNumero2() {
        return $this->numero2;
    }

    public function setResultado($resultado) {
        $this->resultado = $resultado;
    }

    public function getResultado() {
        return $this->resultado;
    }

    public function soma() {
        $this->resultado = $this->numero1 + $this->numero2;
    }

    public function sub() {
        $this->resultado = $this->numero1 - $this->numero2;
    }

    public function div() {
        if ($this->numero2 == 0) {
            throw new Exception("Divisão por zero não permitida");
        }
        $this->resultado = $this->numero1 / $this->numero2;
    }

    public function mult() {
        $this->resultado = $this->numero1 * $this->numero2;
    }
}
