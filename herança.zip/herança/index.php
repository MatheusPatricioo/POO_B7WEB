<?php

require ("animal.php");

// Instanciação e utilização das classes
$meuCachorro = new Cachorro();
$meuCachorro->setSpeed(100);
$meuCachorro->setLatido("au aux  ");
echo "a velocidade do cao é: " . $meuCachorro->getSpeed() . "<br>";
echo $meuCachorro->getLatido();


$meuGato = new Gato();
$meuGato->setSpeed(80);
echo "a velocidade do gato é: " . $meuGato->getSpeed() . "<br>";

