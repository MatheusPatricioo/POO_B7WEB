<?php
class Animal {
    private int $speed;
    private bool $fly;

    public function __construct() {
        $this->speed = 0;
        $this->fly = false;
    }

    public function getSpeed(): int {
        return $this->speed;
    }

    public function getFly(): bool {
        return $this->fly;
    }

    public function setSpeed(int $speed) {
        $this->speed = $speed;
    }

    public function setFly(bool $fly) {
        $this->fly = $fly;
    }

    public function correndo() {
        $this->setSpeed(1);
    }
}

class Cachorro extends Animal {
    // ... métodos específicos para cachorro
    private string $latido;

    public function getLatido(): string {
        return $this->latido;
    }

    public function setLatido(string $novoLatido): void {
        $this->latido = $novoLatido;
    }
}


class Gato extends Animal {
    // ... métodos específicos para gato
}

